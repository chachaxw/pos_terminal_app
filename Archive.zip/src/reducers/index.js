import { combineReducers } from 'redux';
import global from './reducer';

const rootReducer = combineReducers({global});

export default rootReducer;